
# lst.prob_dists no longer needed 
geneclusterranking <- function(df.genomicClusters = df.genomicClusters, mat.pcc = mat.pcc, v.top_99 = NULL){ # lst.prob_dists
  
  #mat.functionalassociation <- mat.pcc
  
  if(is.null(v.top_99)){
    v.top_99 <- quantile(mat.pcc, 0.99)
  }
  
  # returns string w/o leading whitespace
  trim.leading <- function (x) sub("^\\s+", "", x)
  # returns string w/o trailing whitespace
  trim.trailing <- function (x) sub("\\s+$", "", x)
  # returns string w/o leading or trailing whitespace
  trim <- function (x) gsub("^\\s+|\\s+$", "", x)
  
  
  # remove whitespaces from gene cluster files
  for(j in 1:ncol(df.genomicClusters)){
    df.genomicClusters[,j]<- sapply(df.genomicClusters[,j], trim)
  }
  
  df.genomicClusters$GeneName <- unlist(sapply(as.character(df.genomicClusters$GeneName), function(m) if(m==""){m<-"other"}else{m}))
  
  
  v.genomicClusters <- unique(df.genomicClusters$ClusterID)
  
  ####
  
  l.gns_on_chip <- length(rownames(mat.pcc))
  

  
  
  gns_on_chip <- intersect(rownames(mat.pcc), unique(df.genomicClusters$GeneID))
  
  
  mat.pcc.gc.filter <- mat.pcc[gns_on_chip,gns_on_chip]
  mat.pcc.gc.filter[mat.pcc.gc.filter < 100] <- 0
  
  mat.pcc.gc <- mat.pcc[gns_on_chip,gns_on_chip]
  
  
  diag(mat.pcc.gc) <- 0
  
  
  mat.pcc.bin <- mat.pcc.gc
  mat.pcc.bin[mat.pcc.bin < v.top_99] <- 0
  mat.pcc.bin[mat.pcc.bin >= v.top_99] <- 1
  mat.pcc.bin <- as(mat.pcc.bin, "CsparseMatrix")
  
  v.gn_names <- df.genomicClusters$GeneName; names(v.gn_names) <- df.genomicClusters$GeneID
  v.gn_rxn_ids <- df.genomicClusters$rxn.id; names(v.gn_rxn_ids) <- df.genomicClusters$GeneID
  v.gn_ecs <- df.genomicClusters$ec; names(v.gn_ecs) <- df.genomicClusters$GeneID
  v.gn_cluster_ids <- df.genomicClusters$ClusterID; names(v.gn_cluster_ids) <- df.genomicClusters$GeneID
  
  df.genomicClusterCoexpression <- data.frame(cluster.ID =  character(), 
                                              gene_A.ID  = character(), 
                                              gene_A_annotation = character(),
                                              gene_A.Name = character(),
                                              gene_A.rxn_ID = character(),
                                              gene_A.rxn_ec = character(),
                                              
                                              max.PCC_inside = numeric(), 
                                              mean.PCC_inside = numeric(), 
                                              min.PCC_inside = numeric(), 
                                              min_greater_zero.PCC_inside = numeric(), 
                                              
                                              gene_B.ID_inside  = character(),
                                              gene_B.Name_inside = character(),
                                              
                                              gene_B.rxn_ID_inside = character(),
                                              gene_B.rxn_ec_inside = character(),
                                              
                                              gene_B.PCC_inside = numeric(),
                                              
                                              stringsAsFactors = FALSE)
  
  
  for(c in 1:length(v.genomicClusters)){
    
    cat("Processing... ", round(c/length(v.genomicClusters) * 100, digits = 2) , "%", "\r"); flush.console()   
    
    v.gns_cluster <- subset(df.genomicClusters, df.genomicClusters$ClusterID == v.genomicClusters[c])$GeneID  
    
    df.genomicClusters.c <- subset(df.genomicClusters, df.genomicClusters$ClusterID == v.genomicClusters[c])  
    gene_B.ID_of_chip <- df.genomicClusters.c$GeneID[!df.genomicClusters.c$GeneID %in% gns_on_chip]
    gene_B.ID_above_cutoff <- character()
    
    df.genomicClusters.c <- subset(df.genomicClusters.c, df.genomicClusters.c$GeneID %in% gns_on_chip)  
    
    #  filter all with less than a least 1 gene pair (on chip)
    if(nrow(df.genomicClusters.c) >= 2){
      
      # might be inflated for gma, sly, osa, zma
      mat.pcc.gc.c <- mat.pcc.gc[df.genomicClusters.c$GeneID,df.genomicClusters.c$GeneID]
      v.gns.gc_c <- rownames(mat.pcc.gc.c)
    
      v.gn_names.gc_c <- df.genomicClusters.c$GeneName; names(v.gn_names.gc_c) <- df.genomicClusters.c$GeneID
      v.gn_rxn_id.gc_c <- df.genomicClusters.c$rxn.id; names(v.gn_rxn_id.gc_c) <- df.genomicClusters.c$GeneID
      v.gn_ec.gc_c <- df.genomicClusters.c$ec; names(v.gn_ec.gc_c) <- df.genomicClusters.c$GeneID
    
      
      idx.filter_statistical_and_biological <- which(mat.pcc.gc.c >= v.top_99, arr.ind = TRUE)
      
      if(length(idx.filter_statistical_and_biological) > 0){
        #     idx.filter_biological <- which(mat.pcc.gc.c[cbind(idx.filter_statistical[,1], idx.filter_statistical[,2])] >= as.numeric(v.top_99))
        #     idx.filter_statistical_and_biological <- idx.filter_statistical[idx.filter_biological,]
        
        for(j in 1:nrow(idx.filter_statistical_and_biological)){
          
          g1 <- idx.filter_statistical_and_biological[j,1]
          #g2 <- idx.filter_statistical_and_biological[j,2] 
          #mat.pcc.gc.c[g1,g2]
          
          gene_A.ID  = v.gns.gc_c[g1]
          gene_B.ID_above_cutoff <- c(gene_B.ID_above_cutoff, gene_A.ID)
          gene_A.Name = v.gn_names.gc_c[v.gns.gc_c[g1]]
          gene_A.annotation = ""
          gene_A.rxn_ID = v.gn_rxn_id.gc_c[v.gns.gc_c[g1]]
          gene_A.rxn_ec = v.gn_ec.gc_c[v.gns.gc_c[g1]]
          
          idx.g1 <- which(rownames(mat.pcc.gc.c) == v.gns.gc_c[g1])
          
          # in cluster
          v.max.c <- max(mat.pcc.gc.c[idx.g1, -idx.g1])
          v.mean.c <- mean(mat.pcc.gc.c[idx.g1, -idx.g1])
          v.min.c <- min(mat.pcc.gc.c[idx.g1, -idx.g1])
          v.min_zero.c <- min(mat.pcc.gc.c[idx.g1, -idx.g1][mat.pcc.gc.c[idx.g1, -idx.g1] > 0])
          
          v.genome_size_on_chip  <- l.gns_on_chip # global
          v.gns_B.c <- colnames(mat.pcc.gc.c[idx.g1, -idx.g1, drop = FALSE])
          v.gn_names_B.c <- v.gn_names.gc_c[v.gns_B.c]
          
          v.pccs.c <- mat.pcc.gc.c[idx.g1, -idx.g1]
          
          names(v.pccs.c) <-  v.gns_B.c
          
          idx.c <- which(v.pccs.c >= v.top_99)
          
          v.gns_B.c.j <- v.gns_B.c[as.numeric(idx.c)]
          v.gn_names_B.c.j <- v.gn_names_B.c[v.gns_B.c.j]
          v.gn_rxn_id.gc_c.j <- v.gn_rxn_id.gc_c[v.gns_B.c.j]
          v.gn_ec.gc_c.j <- v.gn_ec.gc_c[v.gns_B.c.j]
          v.pccs.c.j <- (v.pccs.c[v.gns_B.c.j])
          
          idx.order <- order(v.pccs.c.j)
          v.gns_B.c.j <- v.gns_B.c.j[idx.order]
          v.gn_names_B.c.j <- as.character(v.gn_names_B.c.j[idx.order])
          v.gn_rxn_id.gc_c.j <- v.gn_rxn_id.gc_c.j[idx.order]
          v.gn_ec.gc_c.j <- v.gn_ec.gc_c.j[idx.order]
          v.pccs.c.j <- v.pccs.c.j[idx.order]
          
          
          df.genomicClusterCoexpression <- rbind(df.genomicClusterCoexpression, data.frame(cluster.ID = v.genomicClusters[c], 
                                                                                           gene_A.ID  = gene_A.ID, 
                                                                                           gene_A_annotation = "",
                                                                                           
                                                                                           gene_A.Name = gene_A.Name,
                                                                                           gene_A.rxn_ID = gene_A.rxn_ID,
                                                                                           gene_A.rxn_ec = gene_A.rxn_ec,
                                                                                           
                                                                                           max.PCC_inside = v.max.c, 
                                                                                           mean.PCC_inside = v.mean.c, 
                                                                                           min.PCC_inside = v.min.c, 
                                                                                           min_greater_zero.PCC_inside = v.min_zero.c, 
                                                                                           
                                                                                           gene_B.ID_inside  = paste(v.gns_B.c.j, collapse="/"),
                                                                                           gene_B.Name_inside = paste(v.gn_names_B.c.j, collapse="/"),
                                                                                           gene_B.rxn_ID_inside = paste(v.gn_rxn_id.gc_c.j, collapse="/"),
                                                                                           gene_B.rxn_ec_inside = paste(v.gn_ec.gc_c.j, collapse="/"),
                                                                                           gene_B.PCC_inside = paste(v.pccs.c.j, collapse="/"),
                                                                                           stringsAsFactors = FALSE))
          
        }
      }
      
      gene_B.ID_below_cutoff <- v.gns.gc_c[!v.gns.gc_c %in% gene_B.ID_above_cutoff]
      
    }else{
      gene_B.ID_below_cutoff <- df.genomicClusters.c$GeneID  
    }
    
    if(length(gene_B.ID_of_chip) > 0){
      for(g in 1:length(gene_B.ID_of_chip)){
        
        df.genomicClusters.c.g <- subset(df.genomicClusters, df.genomicClusters$GeneID == gene_B.ID_of_chip[g])
        
        
        df.genomicClusterCoexpression <- rbind(df.genomicClusterCoexpression, data.frame(cluster.ID = v.genomicClusters[c], 
                                                                                         gene_A.ID  = gene_B.ID_of_chip[g],
                                                                                         gene_A_annotation = "gene off chip",
                                                                                         
                                                                                         gene_A.Name = as.character(df.genomicClusters.c.g$GeneName),
                                                                                         gene_A.rxn_ID = as.character(df.genomicClusters.c.g$rxn.id),
                                                                                         gene_A.rxn_ec = as.character(df.genomicClusters.c.g$ec),
                                                                                         
                                                                                         max.PCC_inside = 0, 
                                                                                         mean.PCC_inside = 0, 
                                                                                         min.PCC_inside = 0, 
                                                                                         min_greater_zero.PCC_inside = 0, 
                                                                                         
                                                                                         gene_B.ID_inside  = "",
                                                                                         gene_B.Name_inside = "",
                                                                                         gene_B.rxn_ID_inside = "",
                                                                                         gene_B.rxn_ec_inside = "",
                                                                                         gene_B.PCC_inside = 0,
                                                                                         stringsAsFactors = FALSE))
      }
    }
    
    
    if(length(gene_B.ID_below_cutoff) > 0){
      for(g in 1:length(gene_B.ID_below_cutoff)){
        df.genomicClusters.c.g <- subset(df.genomicClusters.c, df.genomicClusters.c$GeneID == gene_B.ID_below_cutoff[g])
        
        
        df.genomicClusterCoexpression <- rbind(df.genomicClusterCoexpression, data.frame(cluster.ID = v.genomicClusters[c], 
                                                                                         gene_A.ID  = gene_B.ID_below_cutoff[g],
                                                                                         gene_A_annotation = "gene below cut",
                                                                                         
                                                                                         gene_A.Name = as.character(df.genomicClusters.c.g$GeneName),
                                                                                         gene_A.rxn_ID = as.character(df.genomicClusters.c.g$rxn.id),
                                                                                         gene_A.rxn_ec = as.character(df.genomicClusters.c.g$ec),
                                                                                         
                                                                                         max.PCC_inside = 0, 
                                                                                         mean.PCC_inside = 0, 
                                                                                         min.PCC_inside = 0, 
                                                                                         min_greater_zero.PCC_inside = 0, 
                                                                                         
                                                                                         gene_B.ID_inside  = "",
                                                                                         gene_B.Name_inside = "",
                                                                                         gene_B.rxn_ID_inside = "",
                                                                                         gene_B.rxn_ec_inside = "",
                                                                                         gene_B.PCC_inside = 0,
                                                                                         
                                                                                         stringsAsFactors = FALSE))
      }
    }
  }
  
  
  
  
  ## the summary - for now most important part ###
  
  df.genomicClusterCoexpression$min_greater_zero.PCC_inside[df.genomicClusterCoexpression$min_greater_zero.PCC_inside == "Inf"] <- NA
  df.genomicClusterCoexpression <- unique(df.genomicClusterCoexpression)
  n.cluster.total <- length(unique(df.genomicClusterCoexpression$cluster.ID))
  
  df.genomicClusterCoexpression.onchip <- df.genomicClusterCoexpression
  df.genomicClusterCoexpression.onchip <- subset(df.genomicClusterCoexpression.onchip, df.genomicClusterCoexpression.onchip$gene_A_annotation != "gene off chip")
  v.genomicClusters <- unique(df.genomicClusterCoexpression.onchip$cluster.ID)
  n.cluster.onchip <- length(v.genomicClusters)
  
  df.genomicClusterCoexpression.coexp <- df.genomicClusterCoexpression.onchip
  v.gene_count <- table(df.genomicClusterCoexpression.coexp$cluster.ID)  
  df.genomicClusterCoexpression.coexp <- subset(df.genomicClusterCoexpression.coexp, df.genomicClusterCoexpression.coexp$gene_A_annotation != "gene below cut")
  v.gene_coexp <- table(df.genomicClusterCoexpression.coexp$cluster.ID)  
  n.cluster.onchip.abovecut <- length(unique(df.genomicClusterCoexpression.coexp$cluster.ID))
  
  
  ## for paper: considers only annotated enzymes - annotated enzymes pairs
  df.genomicClusterCoexpression.enzymes <- df.genomicClusterCoexpression.onchip
  df.genomicClusterCoexpression.enzymes <- subset(df.genomicClusterCoexpression.enzymes, !df.genomicClusterCoexpression.enzymes$gene_A.rxn_ID %in% c("[]", "[]/[]", "[]/[]/[]", "[]/[]/[]/[]", "[]/[]/[]/[]/[]", "[]/[]/[]/[]/[]/[]"))
  v.enzyme_count <- table(df.genomicClusterCoexpression.enzymes$cluster.ID)
  
  df.genomicClusterCoexpression.enzymes <- subset(df.genomicClusterCoexpression.enzymes, df.genomicClusterCoexpression.enzymes$gene_A_annotation != "gene below cut")
  df.genomicClusterCoexpression.enzymes <- subset(df.genomicClusterCoexpression.enzymes, !df.genomicClusterCoexpression.enzymes$gene_B.rxn_ID_inside %in% c("[]", "[]/[]", "[]/[]/[]", "[]/[]/[]/[]", "[]/[]/[]/[]/[]", "[]/[]/[]/[]/[]/[]"))
  v.enzyme_coexp <- table(df.genomicClusterCoexpression.enzymes$cluster.ID)
  
  
  ## clusters with at least one coexpressed enzyme pair
  n.cluster.coexp.enzymes <- length(unique(df.genomicClusterCoexpression.enzymes$cluster.ID))
  
  
  #### 
  
  #   v.gene_coexp.complete <- numeric(length(v.enzyme_count))
  #   names(v.gene_coexp.complete) <- names(v.enzyme_count)
  #   v.gene_coexp.complete[names(v.gene_coexp)] <- v.gene_coexp
  # 
  #   v.enzyme_coexp.complete <- numeric(length(v.enzyme_count))
  #   names(v.enzyme_coexp.complete) <- names(v.enzyme_count)
  #   v.enzyme_coexp.complete[names(v.enzyme_coexp)] <- v.enzyme_coexp
  
  ####
  
  #j12 <- df.genomicClusters
  #j13 <- subset(j12,j12$ClusterID==v.genomicClusters)
  
  df.newframeforsize <- data.frame(clusteridvalue = character(), sizevale  = character())
  for(kfj in 1:length(names(v.enzyme_count))){
    valueofsize <- grep(names(v.enzyme_count)[kfj],names(table(df.genomicClusters$ClusterID)))
    df.newframeforsize <- rbind(df.newframeforsize,data.frame(clusteridvalue = names(v.enzyme_count)[kfj], 
                                                              sizevalue = as.numeric(table(df.genomicClusters$ClusterID))[valueofsize]))
  }
  
  ##gc.summary <- data.frame(v1=names(v.enzyme_count), v2=as.numeric(table(df.genomicClusters$ClusterID)), v3=as.numeric(v.enzyme_count), v4=rep(0, length(v.enzyme_count)),  v5=rep(0, length(v.enzyme_count)), v6=rep(0, length(v.enzyme_count)), stringsAsFactors = FALSE)
  #gc.summary <- data.frame(v1=names(v.enzyme_count), v2=names(v.enzyme_count), v3=as.numeric(v.enzyme_count), v4=rep(0, length(v.enzyme_count)),  v5=rep(0, length(v.enzyme_count)), v6=rep(0, length(v.enzyme_count)), stringsAsFactors = FALSE)
  #as.numeric(table(df.genomicClusters$ClusterID))
  
  gc.summary <- data.frame(v1=names(v.enzyme_count), v2=as.numeric(df.newframeforsize$sizevalue), v3=as.numeric(v.enzyme_count), v4=rep(0, length(v.enzyme_count)),  v5=rep(0, length(v.enzyme_count)), v6=rep(0, length(v.enzyme_count)),  v5=rep(-1, length(v.enzyme_count)), v6=rep(-1, length(v.enzyme_count)), stringsAsFactors = FALSE)
  names(gc.summary) <- c("cluster.ID", "cluster_size", "number of enzymes (on chip, with rxn annotation (no []))", "number of enzymes (min 1 coexpression partner,  with rxn annotation (no []))", "number of coexpressed genes pairs", "number of coexpressed enzymes pairs", "case a: E -> G1 G2", "case b: E1 E2 -> G")
  
  ####
  
  p.coex.pair = 0.01
  p.noncoex.pair = 0.99
  
  #gc.summary["p.cluster_validity"] <- -1
  gc.summary["p.cluster_rank.all_enzymes_considered"] <- 100
  gc.summary["p.cluster_rank.enzymes_with_min_1_coex_interaction_considered"] <- 100
  gc.summary['p.cluster_rank_nonpenalty'] <- 100
  
  #gc.summary['distance.coexp_genes'] <- -1
  gc.summary[,unique(df.genomicClusterCoexpression.enzymes$gene_A.Name)] <- 0
  
  #which(gc.summary$cluster.ID == "C1149_4")
  
  for(c in 1:nrow(gc.summary)){
    
    n.genes <- nrow(subset(df.genomicClusters, df.genomicClusters$ClusterID == gc.summary$cluster.ID[c])) #as.numeric(v.gene_count[c])
    
    # coexpressed genes (everything per cluster)
    df.genomicCluster.coexp.c <- subset(df.genomicClusterCoexpression.coexp, df.genomicClusterCoexpression.coexp$cluster.ID == gc.summary$cluster.ID[c])
    v.gene.coexp <- unique(df.genomicCluster.coexp.c$gene_A.ID)
  
    if(length(v.gene.coexp) >= 2){
    
      # case a: E -> G1, G2
      identity.set <- which(mat.pcc.gc.filter[v.gene.coexp,v.gene.coexp] == 100, arr.ind = TRUE)
      gc.summary$`case a: E -> G1 G2`[c] <- any((identity.set[,1] - identity.set[,2]) != 0)
      
      # v.coexp.filter <- names(which((identity.set[,1] - identity.set[,2]) != 0))
      # v.gene.coexp <- v.gene.coexp[!v.gene.coexp %in% v.enzymes.filter]
      
      ###  
      n.genes_coexp <- length(v.gene.coexp)
      n.coex_genes_interactions <- sum(mat.pcc.bin[v.gene.coexp,v.gene.coexp])/2
      gc.summary$`number of coexpressed genes pairs`[c] <- n.coex_genes_interactions
      
      # coexpressed enzymes per cluster
      v.enzyme.coexp <- subset(df.genomicClusterCoexpression.enzymes, df.genomicClusterCoexpression.enzymes$cluster.ID == gc.summary$cluster.ID[c])$gene_A.ID
      n.enzymes.coexp <- length(v.enzyme.coexp) 
      gc.summary$`number of enzymes (min 1 coexpression partner,  with rxn annotation (no []))`[c] <- n.enzymes.coexp
      n.coex_enzyme_pairs <- sum(mat.pcc.bin[v.enzyme.coexp,v.enzyme.coexp])/2
      gc.summary$`number of coexpressed enzymes pairs`[c] <- n.coex_enzyme_pairs
      v.signature_enzymes <- table(subset(df.genomicClusterCoexpression.enzymes, df.genomicClusterCoexpression.enzymes$cluster.ID == gc.summary$cluster.ID[c])$gene_A.Name)
      
      if(n.coex_genes_interactions > 0){
        
        # case b: E1, E2 -> G
        gc.summary$`case b: E1 E2 -> G`[c] <- any(table(rownames(mat.pcc.bin[v.gene.coexp,v.gene.coexp])) > 1)
        
        ###
        
        #gc.summary$p.cluster_validity[c] <- lst.prob_dists[[as.character(n.genes)]]$prob.s(n.coex_genes_interactions)
        
        n.enzymes <- gc.summary$`number of enzymes (on chip, with rxn annotation (no []))`[c]
        n.non_coex_enzyme_pairs <- (n.enzymes * n.enzymes - n.enzymes) / 2 - n.coex_enzyme_pairs
        n.totalinteractions = (n.coex_enzyme_pairs + n.non_coex_enzyme_pairs)
        gc.summary$p.cluster_rank.all_enzymes_considered[c] <- nchoosek(n.totalinteractions, n.coex_enzyme_pairs) * p.coex.pair^n.coex_enzyme_pairs * p.noncoex.pair^n.non_coex_enzyme_pairs # cluster rank
        
        n.enzymes <- gc.summary$`number of enzymes (min 1 coexpression partner,  with rxn annotation (no []))`[c]
        n.non_coex_enzyme_pairs <- (n.enzymes * n.enzymes - n.enzymes) / 2 - n.coex_enzyme_pairs
        n.totalinteractions = (n.coex_enzyme_pairs + n.non_coex_enzyme_pairs)
        gc.summary$p.cluster_rank.enzymes_with_min_1_coex_interaction_considered[c] <- nchoosek(n.totalinteractions,n.coex_enzyme_pairs) * p.coex.pair^n.coex_enzyme_pairs * p.noncoex.pair^n.non_coex_enzyme_pairs # cluster rank
        
        gc.summary$p.cluster_rank_nonpenalty[c] <- p.coex.pair^n.coex_enzyme_pairs
        gc.summary[c,names(v.signature_enzymes)] <- as.numeric(v.signature_enzymes)
      }
    }
  }
  
  gc.summary <- gc.summary[order(gc.summary$p.cluster_rank.all_enzymes_considered),]
  
  # no more p value based constraint
  gc.summary.final_selection <- subset(gc.summary, gc.summary$`number of enzymes (min 1 coexpression partner,  with rxn annotation (no []))` > 0)
  
  #gc.summary.final_selection <- subset(gc.summary, gc.summary$`number of enzymes (min 1 coexpression partner,  with rxn annotation (no []))` > 0 & gc.summary$p.cluster_validity > 0.5)
  n.cluster.final_selection <- nrow(gc.summary.final_selection)
  
  ratios = data.frame(specs = c("total_number_of_predicted_clusters", "number_of_cluster_onchip", "number_of_clusters_with_min_one_coexp_genepair", "number_of_clusters_with_min_one_enzyme_genepair", "number_of_clusters_in_final_selection_higher_0.5_validity"),
                      vals  = c(n.cluster.total, n.cluster.onchip, n.cluster.onchip.abovecut,n.cluster.coexp.enzymes, n.cluster.final_selection))
  
  return(list(df.genomicClusterCoexpression=df.genomicClusterCoexpression, gc.summary=gc.summary, gc.summary.final_selection=gc.summary.final_selection,ratios=ratios))
}



# returns string w/o leading whitespace
trim.leading <- function (x) sub("^\\s+", "", x)
# returns string w/o trailing whitespace
trim.trailing <- function (x) sub("\\s+$", "", x)
# returns string w/o leading or trailing whitespace
trim <- function (x) gsub("^\\s+|\\s+$", "", x)


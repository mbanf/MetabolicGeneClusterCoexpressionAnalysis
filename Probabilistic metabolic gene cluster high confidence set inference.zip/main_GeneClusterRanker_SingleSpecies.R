

rm(list=ls())

homeFolder <- "/Users/michaelbanf/Documents/postdoctoral_work/Projects/GeneClusterRankerV1.0/"

setwd(homeFolder)

source("geneClusterRankingAlgorithm_SingleSpecies.R")

if(FALSE){
  install.packages("pracma")  
  install.packages("plyr")
  install.packages("reshape2")
  install.packages("Matrix")
  install.packages("quadprog")
  install.packages("ggplot2")
}

library(pracma)
library(plyr)
library(reshape2)
library(Matrix)
library(quadprog)
library(ggplot2)


# paramters
th.pcc_distribution = 0.99
th.pvalue_clusters = 1e-2

# p value for verification of statistical significance 
th.p.value.coexpression <- 0.01

b.loadCoexpressionMatrix <- FALSE

if(b.loadCoexpressionMatrix){
  # matrix should be prepared and saved as R matrix in a rds file first
  filename.coexpressionMatrix = "datasets/mat.pcc_ath.rds"  
}else{
  # build coexpressionmatrix from scratch - rows genes, columns treatments
  filename.geneExpression = "datasets/GeneExp_v3_MA.txt"  
}


filename.genecluster <- "datasets/geneInCluster_3_aracyc.txt-labeled_NoHypoGenes.txt"

foldername.output <- paste(homeFolder, "output/", sep = "")

filename.analysis_genecluster = paste(foldername.output ,"analysis_genecluster.csv", sep = "")
filename.summary_genecluster = paste(foldername.output ,"summary_genecluster.csv", sep = "")
filename.finalSelection_genecluster = paste(foldername.output ,"summary.final_selection.csv", sep = "")

filename.GeneClusterCoexpression = paste(foldername.output, "geneClustersWithCoexpressionSupport", sep = "")
filename.GeneClusterHighconfidence = paste(foldername.output, "geneClustersHighConfidenceWithStrongCoexpressionSupport", sep = "")


if (!file.exists(foldername.output)){
  dir.create(file.path(foldername.output))
}


# functions to clean gene cluster files from whitespaces 

message("compute coexpression percentile thresholds")

if(b.loadCoexpressionMatrix){
  
  message("load co-expression matrix...")
  mat.pcc <- readRDS(coexpressionMatrixFilename)  
  message("...done")
  
}else{
  
  # first column is the gene identifier 
  df.geneExpression <- read.table(filename.geneExpression, header = TRUE, sep = "\t", stringsAsFactors = FALSE)
  
  # simple pcc matrix construction (no normalization etc. )
  message("build co-expression matrix...")
  
  geneNames <- df.geneExpression[,1]
  df.geneExpression <- df.geneExpression[,-1]
  mat.pcc <- cor(t(df.geneExpression))
  rownames(mat.pcc) <- colnames(mat.pcc) <- toupper(geneNames)
  
  message("...done")
  
}

th.pcc <- quantile(m.pcc, th.pcc_distribution)
    
#df.geneExpression

message("build co-expression matrix...")
if(!b.loadCoexpressionMatrix){
 
  n.samples <- dim(df.geneExpression)[2]
  n.genes <- dim(df.geneExpression)[1]
  ss = (th.pcc * sqrt( n.samples - 1)) / sqrt(1 - th.pcc^2)
  
  p.value <- dt(ss, n.samples - 2)
  p.value <- p.value * n.genes
  
  # use the appropriate threshold
  if(p.value < th.p.value.coexpression){
    message("the selected coexpression threshold is significant, with respect to the number of samples in the gene expression dataset ")
  }else{
    message(paste("Warning: the selected coexpression threshold produces insignificant results, with respect to the number of samples in the gene expression dataset." ))
  }

}
 
message("...done")

#####

df.genomicClusters <- read.table(filename.genecluster, sep = "\t", header = FALSE, skip= 1, stringsAsFactors = FALSE, quote = "")
names(df.genomicClusters) <- c("id", "GeneName", "GeneID", "ClusterID", "rxn.id", "ec", "pwy.id","pwy_of_gene", "Main_functional_domains", "SM_functional_domains")

# remove whitespaces from gene cluster files
for(j in 1:ncol(df.genomicClusters)){
  df.genomicClusters[,j]<- sapply(df.genomicClusters[,j], trim)
}



message("number of gene clusters")
print(length(unique(df.genomicClusters$ClusterID)))
message("number of genes across clusters")
print(length(unique(df.genomicClusters$GeneID)))
message("number of genes across clusters with expression data")
print(length(intersect(unique(df.genomicClusters$GeneID), rownames(m.pcc))))



message("perform gene cluster coexpression analysis..")

lst.genecluster.analysis <- geneclusterranking(df.genomicClusters = df.genomicClusters, mat.pcc = mat.pcc, v.top_99 = th.pcc) #lst.prob_dists

write.csv(lst.genecluster.analysis$df.genomicClusterCoexpression, filename.analysis_genecluster, row.names = FALSE)
write.csv(lst.genecluster.analysis$gc.summary, filename.summary_genecluster, row.names = FALSE)
write.csv(lst.genecluster.analysis$gc.summary.final_selection, filename.finalSelection_genecluster, row.names = FALSE)

message("...done")


## probability for species 
message("Estimate ranking curve elbow point as ..")

ggdata <- melt(data.frame(p.ranking = lst.genecluster.analysis$gc.summary.final_selection$p.cluster_rank.all_enzymes_considered))

# Set the data frame, & add ecdf() data.
ggdata <- ddply(ggdata, .(variable), transform, ecd=ecdf(value)(value))

# cdf <- ggplot(ggdata, aes(x=value)) + stat_ecdf(aes(colour=variable)) + xlab("p.ranking") + ylab("Cumulative probability") + theme_bw() + theme(legend.position = "none") + ggtitle(paste("Cumulative distribution (integrating all rankings across species)", sep = ""))
cdf.log <- ggplot(ggdata, aes(x=value)) + stat_ecdf(aes(colour=variable)) + scale_x_log10() + xlab("p.ranking (log scaled)") + ylab("Cumulative probability")  + theme_bw() + theme(legend.position = "none")+ ggtitle(paste("Estimate ranking threshold (black line) - vary", th.pvalue_clusters)) + geom_vline(xintercept=th.pvalue_clusters)

plot(cdf.log)



### Post-process intergrate ranks per species - manual ##
message("Select high confidence cluster based on ranking threshold")
gc.summary.final_selection <- lst.genecluster.analysis$gc.summary.final_selection
rownames(gc.summary.final_selection) <- gc.summary.final_selection$cluster.ID
p.values <- gc.summary.final_selection$p.cluster_rank.all_enzymes_considered
names(p.values) <-  gc.summary.final_selection$cluster.ID

df.genomicClusters.coexpression <- subset(df.genomicClusters, df.genomicClusters$ClusterID %in% names(p.values))
idx.high_confidence <- which(p.values <= th.pvalue_clusters)
df.genomicClusters.high_confidence <- subset(df.genomicClusters.coexpression, df.genomicClusters.coexpression$ClusterID %in% names(p.values)[idx.high_confidence])

message("number of gene clusters with general coexpression support")
print(length(unique(df.genomicClusters.coexpression$ClusterID)))
message("number of high confidence gene clusters with strong coexpression support")
print(length(unique(df.genomicClusters.high_confidence$ClusterID)))
print("")

write.table(df.genomicClusters.coexpression, filename.GeneClusterCoexpression,sep = "\t",  row.names = FALSE)
write.table(df.genomicClusters.high_confidence, filename.GeneClusterHighconfidence ,sep = "\t",  row.names = FALSE)




### END HERE














